#######################################################################################################################
# Import Packages
#######################################################################################################################
import numpy as np
import pandas as pd
from tensorflow import keras
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import tensorflow_addons as tfa
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import os
os.environ['TF_XLA_FLAGS'] = '--tf_xla_enable_xla_devices'
#######################################################################################################################
def tokentoken(articles):
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(articles)
    # 빈도수 낮은 단어수 체크
    threshold = 3
    words_cnt = len(tokenizer.word_index)
    rare_cnt = 0
    words_freq = 0
    rare_freq = 0

    for key, value in tokenizer.word_counts.items():
        words_freq = words_freq + value
        if value < threshold:
            rare_cnt += 1
            rare_freq = rare_freq + value
    print("전체단어수", words_cnt)
    print(f"빈도수 {threshold-1} 이하인 단어수:", rare_cnt)
    print("희귀 단어 비율:", rare_cnt / words_cnt )
    print("희귀 단어 등장 빈도 비율:", rare_freq / words_freq)
    # 제거
    vocab_size = words_cnt - rare_cnt + 2
    tokenizer = Tokenizer(vocab_size, oov_token='OOV')
    tokenizer.fit_on_texts(articles)
    # 토큰화
    articles = tokenizer.texts_to_sequences(articles)
    return articles, vocab_size
#######################################################################################################################
# Import Data & Tokenizer
#######################################################################################################################
df_resize = pd.read_excel('News_a_resize.xlsx')
df_re = pd.read_excel('News_re_a_whole.xlsx')
df_3 = pd.read_excel('3_whole_2.xlsx')
df_a = pd.read_excel('a_whole_2.xlsx')
df = pd.concat((df_resize,df_re, df_3,df_a), axis=0)
print(df_resize.shape, df_3.shape, df_a.shape)
articles = df['Text'].str.replace("[","").str.replace("]","").str.replace("'","").str.split(", ").to_list()
articles, vocab_size = tokentoken(articles)
# print(sum(len(l) for l in articles)/len(articles))
# plt.hist([len(s) for s in articles], bins=50)
# plt.xlabel('length')
# plt.ylabel('count')
# plt.show()
# 118 -> 236 -> 250,300
# 600
max_len = 600
articles = pad_sequences(articles, maxlen = max_len)
df['Text']=articles.tolist()

num_resize = df_resize.shape[0]
num_re = df_re.shape[0]
num_3 = df_3.shape[0]
num_a = df_a.shape[0]

df_resize_padded = df.iloc[:num_resize]
df_re_padded = df.iloc[num_resize:num_resize+num_re]
df_3_padded = df.iloc[num_resize + num_re:num_resize + num_re + num_3]
df_a_padded = df.iloc[num_resize + num_re + num_3:]

df_resize_padded.to_excel('News_a_resize_padded.xlsx')
df_re_padded.to_excel('News_re_padded.xlsx')
df_3_padded.to_excel('3_whole_padded_ver3.xlsx')
df_a_padded.to_excel('a_whole_padded_ver3.xlsx')
# #######################################################################################################################
# # Train/Test set
# #######################################################################################################################
tmp_articles_resize = df_resize_padded['Text'].to_numpy()
articles_resize = np.array([i for i in tmp_articles_resize], dtype=np.int)
labels_resize = df_resize_padded['Sentiment'].to_numpy(dtype=np.int)
print(articles_resize.shape)
tmp_articles_re = df_re_padded['Text'].to_numpy()
articles_re = np.array([i for i in tmp_articles_re], dtype=np.int)
labels_re = df_re_padded['Sentiment'].to_numpy(dtype=np.int)
print(articles_re.shape)
tmp_articles_3 = df_3_padded['Text'].to_numpy()
articles_3 = np.array([i for i in tmp_articles_3], dtype=np.int)
labels_3 = df_3_padded['Sentiment'].to_numpy(dtype=np.int)
print(articles_3.shape)
tmp_articles_a = df_a_padded['Text'].to_numpy()
articles_a = np.array([i for i in tmp_articles_a], dtype=np.int)
labels_a = df_a_padded['Sentiment'].to_numpy(dtype=np.int)
print(articles_a.shape)

X_train, X_test, y_train, y_test = train_test_split(articles_resize, labels_resize, test_size=0.2, stratify=labels_resize)
#######################################################################################################################
# Keras model
#######################################################################################################################
# model
model = keras.Sequential()
model.add(keras.layers.Embedding(input_dim=vocab_size, output_dim=64, input_length=max_len))
model.add(keras.layers.Dropout(rate=0.2))
model.add(keras.layers.Bidirectional(keras.layers.LSTM(64, return_sequences=True)))
model.add(keras.layers.Dropout(rate=0.2))
model.add(keras.layers.Bidirectional(keras.layers.LSTM(32, return_sequences=False)))
model.add(keras.layers.Dropout(rate=0.2))
model.add(keras.layers.Dense(units=1, activation='sigmoid'))
# compile
rmsprop = keras.optimizers.RMSprop(learning_rate=1e-4)
model.compile(optimizer='adam', loss='binary_crossentropy', metrics='accuracy')
# model summary
model.summary()
#######################################################################################################################
# Keras 수행
#######################################################################################################################
early_stop = keras.callbacks.EarlyStopping(patience=25, restore_best_weights=True,)
check_point = keras.callbacks.ModelCheckpoint('news.h5', save_best_only=True)
print('1')
history = model.fit(X_train,y_train, epochs=1000, batch_size=64,
                    validation_split=0.2, validation_batch_size=64,
                    callbacks=[early_stop, check_point]
                    )
print('2')
# hist = pd.DataFrame(history.history)
# hist.plot()
# plt.show()
#######################################################################################################################
# Keras 저장
#######################################################################################################################
model.save('onehot.h5')
# model = keras.models.load_model('onehot.h5')

#######################################################################################################################
# Keras 예측 1
#######################################################################################################################
model.evaluate(X_test, y_test)
pred = model.predict(X_test)
pd.DataFrame(pred).to_excel('onehot_resize_pred.xlsx')
pd.DataFrame(y_test).to_excel('onehot_resize_label.xlsx')

#######################################################################################################################
# Keras 예측 2
#######################################################################################################################
model.evaluate(articles_re, labels_re)
pred = model.predict(articles_re)
pd.DataFrame(pred).to_excel('onehot_re_pred.xlsx')
pd.DataFrame(labels_re).to_excel('onehot_re_label.xlsx')

#######################################################################################################################
# Keras 예측 3
#######################################################################################################################
pred = model.predict(articles_3)
pd.DataFrame(pred).to_excel('onehot_3_pred.xlsx')

pred = model.predict(articles_a)
pd.DataFrame(pred).to_excel('onehot_a_pred.xlsx')





#######################################################################################################################
# 내 전처리 파일로.
#######################################################################################################################
#######################################################################################################################
# optimizer, layers, dropout, activation
#######################################################################################################################
# 빈도수 2이하 제거
#     rmsprop - 79, 74, 73, 74, 73, 75, 75, 77, 70, 71 - selu, no dropout, patience5        *
#               76.53, 74.73, 75.81, 74.01, 74.73 - selu, no dropout, patience5
#               74.73, 74.01, 76.53, 55 - selu, no dropout, patience3
#               71.48, 71.12, 69.31, 73.65, 71.12 - selu, no dropout, patience7
#               76.53, 72.56, 75.45, 72.92, 75.45 - selu, no dropout, patience6
#               73.29,  72.92, 75.81, 66.6, 73.65, 72.20 - selu, no dropout, patience25
#     adam -    65.70, 72.92, 69.68, 67.15, 68.95 - selu,, no dropout, patience25
#               74.01, 70.04, 65.34, 72.20, 72.56, 71.48 - selu, no dropout, patience4
#               73.65, 69.68, 74.37 - selu, no dropout, patience5
#               67.87, 67.87 - selu, no dropout, patience10
#     rmsprop - 76.90, 73.29, 75.81, 75.81, 70.76 - selu, adding dropout 0.5, patience25    **
#               76.53, 72.56, 45.13, 44.04 - selu, dropout 0.5, patience5
#               74.37, 72.56, 76.53, 73.29, 72.56, 49.46 - selu, dropout 0.5, patience10
#               76.53, 75.45 - selu, dropout 0.5, patience20
#               75.45, 79.78, 76.17, 76.17, 71.12 - selu, dropout 0.5, patience25 - 2dense  ***
#               73.65, 71.84, 71.48, 68.95 - selu, dropout 0.5, patience25 - 2dense - bilstm
#               72.92, 73.65, 79.06 74.73, 73.29, 75.09 - dropout 0.5, patience25 - 2dense  ***
#               76.53, 74.37, 76.17, 77.62, 76.50, 77.62 - dropout 0.2, patience25 - 2dense  ****
#               74.37, 73.29, 76.17, 71.84, 73.65 - dropout 0.2, patience25 - 2dense + bilstm
#     rmsprop - 73.29, 74.01, 73.29, 72.20, 71.84 - elu, no dropout, patience25
#     rmsprop - 72.56, 74.73, 74.73, 72.20 74.01 - relu, no dropout, patience25
#
# 모델 : bilstm 2 layers에 바로 dense layer
# dropout = 0.2
# activation = 없음 (중간에 껴있던 dense layers를 제거해서)
# optimizer = radam, adam, rmsprop 세가지중 rmsprop 이 제일 좋음
#######################################################################################################################
# 빈도수
#######################################################################################################################
# 제거 안함
#     74.01, 70.40, 75.81, 77.98, 76.17, 72.20, 72.92, 72.2, 76.53
# 빈도수 1이하 제거 (18710 - 7690) = 4/9
#     75.81, 73.29, 75.81, 74.37, 77.26, 75.09, 75.81
# 빈도수 2 이하 제거 (18710 - 10323) = 5/9     ***
#     76.53, 74.37, 76.17, 77.62, 76.50, 77.62, 75.09, 76.17, 77.26, 80.87, 74.73, 76.90, 76.17
# 빈도수 4이하 제거 (18710 - 12659) = 1/3
#     72.56, 80.14, 70.76, 76.53, 76.90. 73.29
# 빈도수 9이하 제거 (18710 - 14878) = 1/5
#     72.92, 74.73, 74.73, 74.43, 72.20, 73.65, 74.37
# 빈도수 14이하 제거 (18710 - 15751) = 1/6
#     75.45, 72.92, 76.90, 73.65, 68.59, 75.81
# 빈도수 19이하 제거 (18710 - 16261) = 1/7
#     74.01, 73.65, 74.01, 76.17, 75.45
# 빈도수 24이하 제거 (18710 - 16609) = 1/9
#     69.68, 80.14, 0.7473, 73.65, 74.73
#
# 위 결과를 미루어 보면 3미만인 단어들 제거하는게 평균적으로 가장 좋은 결과를 보임.
#######################################################################################################################
# 단어수 (위 결과들은 600개 기준)
#######################################################################################################################
# 150
#     72.92, 73.65, 75.09, 73.65, 73.65, 71.48, 75.45, 67.15, 76.53, 71.84
# 200
#     72.92, 76.90, 74.01, 71.12, 74.73, 72.20. 76.17, 75.09, 73.29, 70.76
# 300
#     71.12, 77.62, 70.76, 75.09, 72.92, 72.20, 75.81, 76.17, 73.29, 72.92
# 450
#     75.45, 74.01, 75.81, 75.09, 78.34, 76.17, 73.29, 72.56, 75.81, 72.20
# 600
#     76.53, 74.37, 76.17, 77.62, 76.50, 77.62, 75.09, 76.17, 77.26, 80.87, 74.73, 76.90, 76.17, 75.09
# 750
#     75.81, 76.17, 71.12, 74.73, 74.73, 76.90, 76.90, 76.53, 75.45, 75.45
# 600과 750이 비슷한 수준의 결과를 보여주는것 같지만 계산에 사용되는 리소스를 생각할때 600이 가장 타당해보임
# 인풋의 평균이 293이었고 대부분이 600 이하에 분포하고 있었음. 평균을 300으로 보고 그 두배인 600으로 세팅한것이 타당했음.
# 결론 인풋의 평균값의 두배를 시퀀스의 길이로 설정하면 됨



#######################################################################################################################
# 가장 최신 전처리 파일 받은 것 -
#######################################################################################################################
#######################################################################################################################
# 단어수
#######################################################################################################################
# 250 - 이번에도 평균의 2배가 제일 좋은 결과를 보이는 듯.
#a     76.75, 70.11, 71.59, 70.48, 78.23, 71.96, 76.75, 74.54, 74.17, 79.70, 73.80
#3     76.26, 76.26, 73.06, 73.97, 75.80, 77.17, 71.23, 76.71, 76.71, 79.00, 76.26
# 300
#a     67.90, 74.91, 75.28, 76.01, 71.22, 72.32, 72.32, 70.48, 75.28, 76.01, 67.90
#3     74.43, 71.69, 74.43, 79.00, 74.43, 74.89, 71.69, 73.52, 73.52, 76.71, 77.17
#######################################################################################################################
# 불용어 적용
#######################################################################################################################
# 3    72.15, 68.49, 71.69, 74.43, 72.60, 71.69, 72.15, 75.80, 71.69, 79.45, 72.15
#######################################################################################################################
# 불용어 없음
#######################################################################################################################
# a    1
# 3    68.49, 71.23, 68.95, 74.89, 71.69, 69.86, 77.17,....
# resize 과정에서 무작위 샘플링 중 영 좋지 않은 샘플들이 걸린것 같다.
# evalutation 값의 fluctuation이 너무 크게 널뛰며, 전체적인 확률이 하락했다.


# C01-1_KM_Data_LabelingResult_incl_resize 파일의 resize 탭 내용을 khaiii로 전처리한 데이터로 학습 시켰으며
# 위 데이터의 테스트 셋과 C03_KM_Text_Preprocessing_2의 resize하지 않은 삼성 전체데이터를 evaluate한 결과입니다.
#######################################################################################################################
# ver2-1    rmsprop
#######################################################################################################################
# resize_test_evaluate
#     73.29, 75.45, 75.45, 76.90, 71.84, 74.01
# whole_evaluate
#     77.94, 72.54, 77.64, 80.95, 78.00, 78.37
#######################################################################################################################
# ver2-2    adam
#######################################################################################################################
# resize_test_evaluate
#     70.40, 75.09, 75.09, 67.87, 74.73, 70.40
# whole_evaluate
#     80.05, 77.10, 81.07, 78.73, 78.97, 71.63


#######################################################################################################################
# ver3
#######################################################################################################################
# resize_test_evaluate
#     75.45, 71.48, 76.17, 73.29, 72.92, 70.04, 73.65, 68.23, 69.31, 74.37,
# whole_evaluate
#     77.27, 79.34, 79.66, 74.97, 79.10, 79.14, 74.77, 81.13, 80.97, 71.35
# resize_test값이 낮은데 전체 기사가 확률이 높다면 그건 높은 확률로 학습이 잘못된것.
# 학습이 제대로 된것인지 아닌지는 결과를 뽑아서 확인해봐야...
# 1: 79.06/77.00
# 2: 80.87/81.49
# 3: 74.01/76.80
# 4: 72.20/77.31
# 위 네개 자료 날림

#######################################################################################################################
# onehot1
#######################################################################################################################
# 1. 72.20, 79.66
# 2. 68.59, 81.17
# 3. 68.95, 82.80
# 4. 71.12, 77.16
# 5. 73.29, 75.80
# 6. 72.20, 76.44
# 7. 70.40, 75.49
# 8. 76.53, 75.76
# 9. 71.48, 72.39
