#######################################################################################################################
# Import Packages
#######################################################################################################################
import numpy as np
import pandas as pd
from tensorflow import keras
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import tensorflow_addons as tfa
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import os
os.environ['TF_XLA_FLAGS'] = '--tf_xla_enable_xla_devices'
#######################################################################################################################
def tokentoken(articles):
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(articles)
    # 빈도수 낮은 단어수 체크
    threshold = 3
    words_cnt = len(tokenizer.word_index)
    rare_cnt = 0
    words_freq = 0
    rare_freq = 0

    for key, value in tokenizer.word_counts.items():
        words_freq = words_freq + value
        if value < threshold:
            rare_cnt += 1
            rare_freq = rare_freq + value
    print("전체단어수", words_cnt)
    print(f"빈도수 {threshold-1} 이하인 단어수:", rare_cnt)
    print("희귀 단어 비율:", rare_cnt / words_cnt )
    print("희귀 단어 등장 빈도 비율:", rare_freq / words_freq)
    # 제거
    vocab_size = words_cnt - rare_cnt + 2
    tokenizer = Tokenizer(vocab_size, oov_token='OOV')
    tokenizer.fit_on_texts(articles)
    # 토큰화
    articles = tokenizer.texts_to_sequences(articles)
    return articles, vocab_size
#######################################################################################################################
# Import Data & Tokenizer
#######################################################################################################################
# No,	Code,	Date,	Journal,	Title,	Text,	URL,	Sentiment
df_full = pd.read_excel('News_di_pre2_tagged.xlsx')
articles = df_full['Text'].str.replace("[","").str.replace("]","").str.replace("'","").str.split(", ").to_list()
articles, vocab_size = tokentoken(articles)
# print(sum(len(l) for l in articles)/len(articles))
# plt.hist([len(s) for s in articles], bins=50)
# plt.xlabel('length')
# plt.ylabel('count')
# plt.show()
# 293 -> 600
max_len = 150
articles = pad_sequences(articles, maxlen = max_len)
df_full['Text']=articles.tolist()
df_full.to_excel('News_di_pre3_padded_sequence.xlsx')
#######################################################################################################################
# Train/Test set
#######################################################################################################################
df_full = pd.read_excel('News_di_pre3_padded_sequence.xlsx')
df_tt = df_full.dropna(how='any')
a_tmp = df_tt['Text'].str.replace("[","").str.replace("]","").str.replace("'","").str.split(", ").to_numpy()
articles = np.array([i for i in a_tmp], dtype=np.int)
labels = df_tt['Sentiment'].to_numpy(dtype=np.int)

total_len = df_tt.shape[0]
train_len = int(df_tt.shape[0] * 0.8)

# X_train = articles[:train_len]
# X_test = articles[train_len:]
# y_train = labels[:train_len]
# y_test = labels[train_len:]
X_train, X_test, y_train, y_test = train_test_split(articles, labels, test_size=0.2, stratify=labels)
#######################################################################################################################
# Keras model
#######################################################################################################################
# model
model = keras.Sequential()
model.add(keras.layers.Embedding(input_dim=vocab_size, output_dim=64, input_length=max_len))
model.add(keras.layers.Dropout(rate=0.2))
model.add(keras.layers.Bidirectional(keras.layers.LSTM(64, return_sequences=True)))
model.add(keras.layers.Dropout(rate=0.2))
model.add(keras.layers.Bidirectional(keras.layers.LSTM(32, return_sequences=False)))
model.add(keras.layers.Dropout(rate=0.2))
model.add(keras.layers.Dense(units=1, activation='sigmoid'))
# compile
rmsprop = keras.optimizers.RMSprop(learning_rate=1e-4)
model.compile(optimizer=rmsprop, loss='binary_crossentropy', metrics='accuracy')
# model summary
model.summary()
#######################################################################################################################
# Keras 수행
#######################################################################################################################
early_stop = keras.callbacks.EarlyStopping(patience=25, restore_best_weights=True,)
check_point = keras.callbacks.ModelCheckpoint('news.h5', save_best_only=True)
history = model.fit(X_train,y_train, epochs=1000, batch_size=64,
                    validation_split=0.2, validation_batch_size=64,
                    callbacks=[early_stop, check_point]
                    )
# hist = pd.DataFrame(history.history)
# hist.plot()
# plt.show()
#######################################################################################################################
# Keras 저장
#######################################################################################################################
model.save('onehot_di.h5')
model = keras.models.load_model('onehot_di.h5')

#######################################################################################################################
# Keras 예측
#######################################################################################################################
model.evaluate(X_test, y_test)
pred = model.predict(X_test)
pd.DataFrame(pred).to_excel('onehot_di_pred.xlsx')
pd.DataFrame(y_test).to_excel('onehot_di_label.xlsx')


#######################################################################################################################
# optimizer, layers, dropout, activation
#######################################################################################################################
# 빈도수 2이하 제거
#     rmsprop - 79, 74, 73, 74, 73, 75, 75, 77, 70, 71 - selu, no dropout, patience5        *
#               76.53, 74.73, 75.81, 74.01, 74.73 - selu, no dropout, patience5
#               74.73, 74.01, 76.53, 55 - selu, no dropout, patience3
#               71.48, 71.12, 69.31, 73.65, 71.12 - selu, no dropout, patience7
#               76.53, 72.56, 75.45, 72.92, 75.45 - selu, no dropout, patience6
#               73.29,  72.92, 75.81, 66.6, 73.65, 72.20 - selu, no dropout, patience25
#     adam -    65.70, 72.92, 69.68, 67.15, 68.95 - selu,, no dropout, patience25
#               74.01, 70.04, 65.34, 72.20, 72.56, 71.48 - selu, no dropout, patience4
#               73.65, 69.68, 74.37 - selu, no dropout, patience5
#               67.87, 67.87 - selu, no dropout, patience10
#     rmsprop - 76.90, 73.29, 75.81, 75.81, 70.76 - selu, adding dropout 0.5, patience25    **
#               76.53, 72.56, 45.13, 44.04 - selu, dropout 0.5, patience5
#               74.37, 72.56, 76.53, 73.29, 72.56, 49.46 - selu, dropout 0.5, patience10
#               76.53, 75.45 - selu, dropout 0.5, patience20
#               75.45, 79.78, 76.17, 76.17, 71.12 - selu, dropout 0.5, patience25 - 2dense  ***
#               73.65, 71.84, 71.48, 68.95 - selu, dropout 0.5, patience25 - 2dense - bilstm
#               72.92, 73.65, 79.06 74.73, 73.29, 75.09 - dropout 0.5, patience25 - 2dense  ***
#               76.53, 74.37, 76.17, 77.62, 76.50, 77.62 - dropout 0.2, patience25 - 2dense  ****
#               74.37, 73.29, 76.17, 71.84, 73.65 - dropout 0.2, patience25 - 2dense + bilstm
#     rmsprop - 73.29, 74.01, 73.29, 72.20, 71.84 - elu, no dropout, patience25
#     rmsprop - 72.56, 74.73, 74.73, 72.20 74.01 - relu, no dropout, patience25
#
# 모델 : bilstm 2 layers에 바로 dense layer
# dropout = 0.2
# activation = 없음 (중간에 껴있던 dense layers를 제거해서)
# optimizer = radam, adam, rmsprop 세가지중 rmsprop 이 제일 좋음
#######################################################################################################################
# 빈도수
#######################################################################################################################
# 제거 안함
#     74.01, 70.40, 75.81, 77.98, 76.17, 72.20, 72.92, 72.2, 76.53
# 빈도수 1이하 제거 (18710 - 7690) = 4/9
#     75.81, 73.29, 75.81, 74.37, 77.26, 75.09, 75.81
# 빈도수 2 이하 제거 (18710 - 10323) = 5/9
#     76.53, 74.37, 76.17, 77.62, 76.50, 77.62, 75.09, 76.17, 77.26, 80.87, 74.73, 76.90, 76.17
# 빈도수 4이하 제거 (18710 - 12659) = 1/3                       ***
#     72.56, 80.14, 70.76, 76.53, 76.90. 73.29
# 빈도수 9이하 제거 (18710 - 14878) = 1/5
#     72.92, 74.73, 74.73, 74.43, 72.20, 73.65, 74.37
# 빈도수 14이하 제거 (18710 - 15751) = 1/6
#     75.45, 72.92, 76.90, 73.65, 68.59, 75.81
# 빈도수 19이하 제거 (18710 - 16261) = 1/7
#     74.01, 73.65, 74.01, 76.17, 75.45
# 빈도수 24이하 제거 (18710 - 16609) = 1/9
#     69.68, 80.14, 0.7473, 73.65, 74.73
#
# 위 결과를 미루어 보면 3미만인 단어들 제거하는게 가장 좋은 결과를 보임.
#######################################################################################################################
# 단어수 (위 결과들은 600개 기준)
#######################################################################################################################
# 150
#     72.92, 73.65, 75.09, 73.65
# 300
#
# 450
#
# 750