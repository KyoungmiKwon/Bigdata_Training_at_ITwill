#######################################################################################################################
# Import Packages
#######################################################################################################################
import numpy as np
import pandas as pd
from tensorflow import keras
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import os
os.environ['TF_XLA_FLAGS'] = '--tf_xla_enable_xla_devices'
#######################################################################################################################
def tokentoken(articles):
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(articles)
    # 빈도수 낮은 단어수 체크
    threshold = 3
    words_cnt = len(tokenizer.word_index)
    rare_cnt = 0
    words_freq = 0
    rare_freq = 0

    for key, value in tokenizer.word_counts.items():
        words_freq = words_freq + value
        if value < threshold:
            rare_cnt += 1
            rare_freq = rare_freq + value
    print("전체단어수", words_cnt)
    print(f"빈도수 {threshold-1} 이하인 단어수:", rare_cnt)
    print("희귀 단어 비율:", rare_cnt / words_cnt )
    print("희귀 단어 등장 빈도 비율:", rare_freq / words_freq)
    # 제거
    vocab_size = words_cnt - rare_cnt + 2
    tokenizer = Tokenizer(vocab_size, oov_token='OOV')
    tokenizer.fit_on_texts(articles)
    # 토큰화
    articles = tokenizer.texts_to_sequences(articles)
    return articles, vocab_size
#######################################################################################################################
# Import Data & Tokenizer
#######################################################################################################################
# No,	Code,	Date,	Journal,	Title,	Text,	URL,	Sentiment
df_full = pd.read_excel('News_Data_pre2_tagged_test.xlsx')
articles = df_full['Text'].str.replace("[","").str.replace("]","").str.replace("'","").str.split(", ").to_list()
articles, vocab_size = tokentoken(articles)
# print(sum(len(l) for l in articles)/len(articles))
# plt.hist([len(s) for s in articles], bins=50)
# plt.xlabel('length')
# plt.ylabel('count')
# plt.show()
# 293 -> 600
max_len = 600
articles = pad_sequences(articles, maxlen = max_len)
df_full['Text']=articles.tolist()
df_full.to_excel('News_Data_pre3_padded_sequence.xlsx')
#######################################################################################################################
# Train/Test set
#######################################################################################################################
df_full = pd.read_excel('News_Data_pre3_padded_sequence.xlsx')
df_tt = df_full.dropna(how='any')
a_tmp = df_tt['Text'].str.replace("[","").str.replace("]","").str.replace("'","").str.split(", ").to_numpy()
articles = np.array([i for i in a_tmp], dtype=np.int)
labels = df_tt['Sentiment'].to_numpy(dtype=np.int)

total_len = df_tt.shape[0]
train_len = int(df_tt.shape[0] * 0.8)

# X_train = articles[:train_len]
# X_test = articles[train_len:]
# y_train = labels[:train_len]
# y_test = labels[train_len:]
X_train, X_test, y_train, y_test = train_test_split(articles, labels, test_size=0.2, stratify=labels)
#######################################################################################################################
# Keras model
#######################################################################################################################
# model
model = keras.Sequential()
model.add(keras.layers.Embedding(input_dim=vocab_size, output_dim=32, input_length=max_len))
model.add(keras.layers.Bidirectional(keras.layers.LSTM(64, return_sequences=True)))
model.add(keras.layers.Bidirectional(keras.layers.LSTM(32, return_sequences=False)))
model.add(keras.layers.Dense(units=16, activation='selu'))
model.add(keras.layers.Dense(units=8, activation='selu'))
model.add(keras.layers.Dense(units=1, activation='sigmoid'))
# compile
rmsprop = keras.optimizers.RMSprop(learning_rate=1e-4)
model.compile(optimizer=rmsprop, loss='binary_crossentropy', metrics='accuracy')
# model summary
model.summary()
#######################################################################################################################
# Keras 수행
#######################################################################################################################
early_stop = keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True,)
check_point = keras.callbacks.ModelCheckpoint('news.h5', save_best_only=True)
history = model.fit(X_train,y_train, epochs=1000, batch_size=64,
                    validation_split=0.2, validation_batch_size=64,
                    callbacks=[early_stop, check_point])
hist = pd.DataFrame(history.history)
hist.plot()
plt.show()
#######################################################################################################################
# Keras 저장
#######################################################################################################################
model.save('news_keras.h5')
model = keras.models.load_model('news_keras.h5')

#######################################################################################################################
# Keras 예측
#######################################################################################################################
model.evaluate(X_test, y_test)